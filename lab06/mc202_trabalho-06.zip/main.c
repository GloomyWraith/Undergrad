#include "album.h"



int main(){


    return 0;
}