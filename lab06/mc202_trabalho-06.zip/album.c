/*

  album.c - implementação de operadores sobre árvore binária de busca,
            usando a temática do album da copa
  
  Autor: Matheus Cerqueira
  
  MC202G+H - 2 semestre de 2022.
  
  Última alteração: 04/11/2022.
  
*/

#include "album.h"



/*
    Implemente aqui as funções que julgar necessárias.
    Outras funções podem ser adicionadas ou modificadas
*/