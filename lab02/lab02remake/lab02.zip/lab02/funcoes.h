#include<stdio.h>
#include<math.h>

int analise_caractere(char, char []);

void converte_nucleo(char [], char []);

int freq_motivo(char [], char []);

void conteudo_gc(char [], int);