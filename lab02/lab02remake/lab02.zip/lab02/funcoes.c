#include"funcoes.h"

int analise_caractere(char, char []){
    //TODO
}

void converte_nucleo(char [], char []){
    //TODO
}

int freq_motivo(char [], char []){
    //TODO
}

void conteudo_gc(char [], int){
    //TODO
}