#include "funcoes.h"

int main(){

    //TODO: defina variaveis

    printf("Digite o caractere 'c':");


    // TODO call analise_caractere

  
  	return 0;
}
