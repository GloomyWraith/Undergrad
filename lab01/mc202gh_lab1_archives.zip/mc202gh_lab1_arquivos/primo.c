#include"funcoes.h"

int main(){

    int n;

    printf("Digite um numero:");

    //TODO: seu codigo vai aqui!!
}