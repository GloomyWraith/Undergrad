#include"funcoes.h"

int is_primo(int n){
    //TODO: escreva o codigo da questão 1
}

float hipotenusa(float c1, float c2){
    //TODO: escreva o codigo da questão 2
}

float cateto_from_matrix(int M[2][2]){
    //TODO: escreva o codigo da questão 3
}