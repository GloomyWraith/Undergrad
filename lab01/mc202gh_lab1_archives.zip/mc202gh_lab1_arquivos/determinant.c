#include"funcoes.h"

int main(){

    int v1,v2,v3,v4;

    int m[2][2];

    //TODO: entrada de dados


    float cateto = cateto_from_matrix(m);


    //TODO: saida de dados

}