#include"funcoes.h"

int main(){
    double cateto1=0, cateto2=0.0;
    double hipo;
    printf("Por favor, digite os dois catetos (ou dois números negativos para parar):\n");

    //TODO: seu codigo vai aqui!!
}