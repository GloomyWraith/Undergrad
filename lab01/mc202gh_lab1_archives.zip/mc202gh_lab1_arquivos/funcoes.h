#include<stdio.h>
//TODO: importe outras bibliotecas, caso precise.


int is_primo(int numero);

float hipotenusa(float c1, float c2);

float cateto_from_matrix(int M[2][2]);