
#include <stdio.h>
#include <stdlib.h>
#include "ficha.h"



float calcula_media_CR (ficha * ptr_estudante, int n)
{
  //TODO
}


int busca_ficha (ficha * ptr_estudante, int n, int RA)
{
  //TODO
}


ficha * cria_fichario (int n)
{
  //TODO
}


ficha le_ficha()
{
  //TODO
}


void imprime_ficha(ficha * estudante)
{
  //TODO
}


int insere_ficha (ficha ** ptr_estudante, int * n, ficha estudante)
{
  //TODO
}


int remove_ficha (ficha * ptr_estudante, int n, int RA)
{
  //TODO
}


/*
   Fim do arquivo.
*/


