#include <stdio.h>
#include <stdlib.h>
#include "ficha.h"


float calcula_media_CR (ficha * ptr_estudante, int n)
{
   //TODO
}


ficha * cria_fichario (int n)
{
  //TODO
}


void imprime_ficha(ficha * estudante)
{
  //TODO
}


int insere_ficha (ficha ** ptr_estudante, int * n, ficha estudante)
{
  //TODO
}


ficha le_ficha()
{
  //TODO
}


/*
   Fim do arquivo.
*/


