#include <stdio.h>
#include <stdlib.h>
#include "ficha.h"


int main ()
{
  //TODO
  return 0;
}

/* Fim do programa */

